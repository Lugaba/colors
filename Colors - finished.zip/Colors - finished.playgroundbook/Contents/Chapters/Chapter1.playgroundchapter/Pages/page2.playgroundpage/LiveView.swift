import Psyco
import PlaygroundSupport

PlaygroundPage.current.needsIndefiniteExecution = true
PlaygroundPage.current.setLiveView(PsycoViewController())
