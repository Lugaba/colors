/*:
 
 Now that we know colors better we can learn something much cooler! Color psychology!
 
 # What is color psychology?
 
 Color psychology is the study that shows how our brain identifies and transforms colors into sensations, trying to understand the human behavior in contact with them. So let's see what each color makes us feel or remember!

 - Important:
 The code is already running, click on the colored buttons to change the feeling to the chosen color.
 */

